package com.example.pintoras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton boton1 = (ImageButton) findViewById(R.id.imageButton);
        boton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast notificacion = Toast.makeText(MainActivity.this, "Leonora Carrington", Toast.LENGTH_SHORT);
                notificacion.show();

                MenuSlideActivity.opcion = 1;
                Intent intencion = new Intent(getApplicationContext(),MenuSlideActivity.class);
                startActivity(intencion);
            }
        });

        ImageButton boton2 = (ImageButton) findViewById(R.id.imageButton2);
        boton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast notificacion = Toast.makeText(MainActivity.this, "Dorothea Tanning", Toast.LENGTH_SHORT);
                notificacion.show();

                MenuSlideActivity.opcion = 2;
                Intent intencion = new Intent(getApplicationContext(),MenuSlideActivity.class);
                startActivity(intencion);
            }
        });

        ImageButton boton3 = (ImageButton) findViewById(R.id.imageButton3);
        boton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast notificacion = Toast.makeText(MainActivity.this, "Maria Izquierdo", Toast.LENGTH_SHORT);
                notificacion.show();

                MenuSlideActivity.opcion = 3;
                Intent intencion = new Intent(getApplicationContext(),MenuSlideActivity.class);
                startActivity(intencion);
            }
        });

        ImageButton boton4 = (ImageButton) findViewById(R.id.imageButton4);
        boton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast notificacion = Toast.makeText(MainActivity.this, "Remedios Varo", Toast.LENGTH_SHORT);
                notificacion.show();

                MenuSlideActivity.opcion = 4;
                Intent intencion = new Intent(getApplicationContext(),MenuSlideActivity.class);
                startActivity(intencion);
            }
        });
    }


    public void onClick(View v) {

    }
}